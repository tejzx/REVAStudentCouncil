import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Calendar, Users, Image, MessageSquare, Star, ChevronRight, Instagram, Zap, Trophy, BookOpen, X } from 'lucide-react';
import { councilInfo, events } from '../data/mockData';

// ─── Cinematic REVOTHSAVA Surprise Box ────────────────────────────────────────
function SurpriseBox() {
  const [phase, setPhase] = useState('idle'); // idle | shaking | revealed
  const canvasRef = useRef(null);
  const animRef = useRef(null);

  const handleClick = () => {
    if (phase !== 'idle') return;
    setPhase('shaking');
    setTimeout(() => setPhase('revealed'), 900);
  };

  const close = () => {
    setPhase('idle');
    if (animRef.current) cancelAnimationFrame(animRef.current);
  };

  // Canvas particle system
  useEffect(() => {
    if (phase !== 'revealed') { if (animRef.current) cancelAnimationFrame(animRef.current); return; }
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
    resize();
    window.addEventListener('resize', resize);

    const COLORS = ['#FFD700', '#F59E0B', '#8B5CF6', '#A78BFA', '#FF6B35', '#FFFFFF', '#E879F9', '#FFF08A', '#FF3131'];
    const particles = [];
    const cx = () => canvas.width / 2;
    const cy = () => canvas.height * 0.42;

    // Initial burst
    for (let i = 0; i < 240; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 5 + Math.random() * 22;
      const isSpark = Math.random() < 0.35;
      const color = COLORS[Math.floor(Math.random() * COLORS.length)];
      const p = {
        x: cx(), y: cy(), px: cx(), py: cy(),
        vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed - (isSpark ? 16 : 9),
        gravity: isSpark ? 0.5 : 0.3,
        alpha: 1, decay: isSpark ? 0.02 : 0.007,
        color, isSpark,
        type: Math.random() < 0.5 ? 'rect' : 'circle',
        w: isSpark ? 2 : 4 + Math.random() * 8,
        h: isSpark ? 2 : 2 + Math.random() * 5,
        rot: Math.random() * 360, rs: (Math.random() - 0.5) * 14,
      };
      particles.push(p);
    }

    let frame = 0;
    const loop = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      frame++;

      // Drizzle new confetti
      if (frame % 3 === 0 && particles.filter(p => p.alpha > 0.05).length < 300) {
        const color = COLORS[Math.floor(Math.random() * COLORS.length)];
        const a = Math.random() * Math.PI * 2, spd = 2 + Math.random() * 7;
        particles.push({
          x: cx() + (Math.random() - 0.5) * 350, y: cy() - 180,
          px: cx(), py: cy() - 180,
          vx: Math.cos(a) * spd, vy: Math.sin(a) * spd - 3,
          gravity: 0.18, alpha: 0.9, decay: 0.004, color, isSpark: false,
          type: Math.random() < 0.5 ? 'rect' : 'circle',
          w: 4 + Math.random() * 6, h: 2 + Math.random() * 4,
          rot: Math.random() * 360, rs: (Math.random() - 0.5) * 9,
        });
      }

      particles.forEach(p => {
        if (p.alpha <= 0.01) return;
        p.px = p.x; p.py = p.y;
        p.x += p.vx; p.y += p.vy;
        p.vy += p.gravity; p.vx *= 0.993;
        p.rot += p.rs; p.alpha -= p.decay;
        ctx.save();
        ctx.globalAlpha = Math.max(0, p.alpha);
        if (p.isSpark) {
          ctx.strokeStyle = p.color; ctx.lineWidth = 2.5;
          ctx.shadowColor = p.color; ctx.shadowBlur = 10;
          ctx.beginPath(); ctx.moveTo(p.px, p.py); ctx.lineTo(p.x, p.y); ctx.stroke();
        } else {
          ctx.translate(p.x, p.y); ctx.rotate(p.rot * Math.PI / 180);
          ctx.fillStyle = p.color; ctx.shadowColor = p.color; ctx.shadowBlur = 5;
          if (p.type === 'rect') ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
          else { ctx.beginPath(); ctx.arc(0, 0, p.w / 2, 0, Math.PI * 2); ctx.fill(); }
        }
        ctx.restore();
      });

      if (frame % 90 === 0) {
        const alive = particles.filter(p => p.alpha > 0.01);
        particles.length = 0; particles.push(...alive);
      }
      animRef.current = requestAnimationFrame(loop);
    };
    loop();
    return () => { cancelAnimationFrame(animRef.current); window.removeEventListener('resize', resize); };
  }, [phase]);

  return (
    <section className="section-padding max-w-7xl mx-auto">
      <AnimatedSection>
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 rounded-full px-4 py-1.5 mb-4"
            style={{ background: 'rgba(139,92,246,0.15)', border: '1px solid rgba(139,92,246,0.3)' }}>
            <span style={{ color: '#A78BFA', fontSize: 11, fontWeight: 700, letterSpacing: '0.4em', textTransform: 'uppercase' }}>
              ✦ Something Special Awaits ✦
            </span>
          </div>
          <h2 className="section-title mb-2">You've Got a Mystery Box 🎁</h2>
          <p className="text-white/40 text-sm">Click the box to reveal what's coming…</p>
        </div>

        {/* Stage */}
        <div className="flex flex-col items-center" style={{ perspective: '1200px' }}>
          <div className="relative flex flex-col items-center" style={{ height: 340 }}>

            {/* Stage spotlights */}
            <div className="absolute inset-0 pointer-events-none overflow-hidden">
              {[{ l: '50%', c: 'rgba(139,92,246,0.18)' }, { l: '28%', c: 'rgba(255,215,0,0.10)' }, { l: '72%', c: 'rgba(255,80,0,0.09)' }].map((s, i) => (
                <div key={i} style={{
                  position: 'absolute', top: -60, left: s.l, transform: 'translateX(-50%)',
                  width: 160, height: 320,
                  background: `conic-gradient(from 174deg at 50% 0%, transparent 0deg, ${s.c} 6deg, transparent 12deg)`,
                  filter: 'blur(6px)',
                }} />
              ))}
            </div>

            {/* The Mystery Box */}
            <button
              onClick={handleClick}
              className="focus:outline-none relative"
              style={{
                animation: phase === 'shaking' ? 'sBoxShake 0.8s ease-in-out'
                         : phase === 'idle'    ? 'sBoxFloat 3s ease-in-out infinite' : 'none',
                opacity: phase === 'revealed' ? 0 : 1,
                transition: 'opacity 0.4s',
                pointerEvents: phase !== 'idle' ? 'none' : 'auto',
                marginTop: 40,
              }}
            >
              {/* Base glow */}
              <div style={{
                position: 'absolute', bottom: -24, left: '50%', transform: 'translateX(-50%)',
                width: 210, height: 28,
                background: 'radial-gradient(ellipse, rgba(139,92,246,0.8) 0%, transparent 70%)',
                filter: 'blur(12px)',
              }} />

              {/* BOW */}
              <div style={{ position: 'absolute', top: -32, left: '50%', transform: 'translateX(-50%)', display: 'flex', alignItems: 'center', justifyContent: 'center', width: 110, zIndex: 10 }}>
                <div style={{ width: 48, height: 34, border: '5px solid #FFD700', borderRadius: '50% 0 50% 50%', transform: 'rotate(-28deg) translateX(10px)', background: 'rgba(245,158,11,0.2)', boxShadow: '0 0 16px rgba(255,215,0,0.6)' }} />
                <div style={{ position: 'absolute', width: 18, height: 18, background: '#FFD700', borderRadius: '50%', boxShadow: '0 0 14px rgba(255,215,0,1), 0 0 28px rgba(255,215,0,0.4)', zIndex: 5 }} />
                <div style={{ width: 48, height: 34, border: '5px solid #FFD700', borderRadius: '0 50% 50% 50%', transform: 'rotate(28deg) translateX(-10px)', background: 'rgba(245,158,11,0.2)', boxShadow: '0 0 16px rgba(255,215,0,0.6)' }} />
              </div>

              {/* Lid */}
              <div style={{
                width: 186, height: 40,
                background: 'linear-gradient(135deg, #7C3AED 0%, #5B21B6 60%, #4C1D95 100%)',
                borderRadius: '10px 10px 0 0',
                border: '2px solid rgba(255,215,0,0.7)',
                boxShadow: '0 -4px 24px rgba(109,40,217,0.5), inset 0 1px 0 rgba(255,255,255,0.2)',
                position: 'relative', overflow: 'hidden',
              }}>
                <div style={{ position: 'absolute', top: 0, bottom: 0, left: '50%', transform: 'translateX(-50%)', width: 24, background: 'linear-gradient(to right, #78350F, #FFD700, #78350F)' }} />
              </div>

              {/* Box body */}
              <div style={{
                width: 186, height: 156,
                background: 'linear-gradient(155deg, #6D28D9 0%, #5B21B6 45%, #4C1D95 100%)',
                borderRadius: '0 0 16px 16px', borderTop: 'none',
                border: '2px solid rgba(255,215,0,0.5)',
                boxShadow: '0 16px 50px rgba(109,40,217,0.8), inset 0 0 40px rgba(139,92,246,0.15)',
                position: 'relative', overflow: 'hidden',
              }}>
                <div style={{ position: 'absolute', top: 0, bottom: 0, left: '50%', transform: 'translateX(-50%)', width: 24, background: 'linear-gradient(to right, #78350F, #FFD700, #78350F)' }} />
                <div style={{ position: 'absolute', left: 0, right: 0, top: '44%', height: 24, background: 'linear-gradient(to bottom, #78350F, #FFD700, #78350F)' }} />
                <div style={{ position: 'absolute', top: 12, left: 16, width: 32, height: 32, background: 'radial-gradient(circle, rgba(255,255,255,0.3) 0%, transparent 70%)', borderRadius: '50%' }} />
                {/* Sparkle corners */}
                {[{t:10,l:10},{t:10,r:10},{b:10,l:10},{b:10,r:10}].map((pos,i) => (
                  <div key={i} style={{
                    position:'absolute', top:pos.t, bottom:pos.b, left:pos.l, right:pos.r,
                    width:8, height:8, background:'#FFD700', borderRadius:'50%',
                    boxShadow:'0 0 10px #FFD700',
                    animation:`sDot ${0.7+i*0.3}s ease-in-out infinite alternate`,
                  }} />
                ))}
              </div>

              <p style={{ marginTop: 12, textAlign: 'center', color: 'rgba(167,139,250,0.8)', fontSize: 11, fontWeight: 700, letterSpacing: '0.35em', textTransform: 'uppercase', animation: 'pulse 2s ease-in-out infinite' }}>
                ✦ Tap to Open ✦
              </p>
            </button>

            {/* Reflective floor */}
            <div style={{
              position: 'absolute', bottom: 0, left: -60, right: -60, height: 40,
              background: 'linear-gradient(to bottom, rgba(109,40,217,0.12), transparent)',
              borderTop: '1px solid rgba(139,92,246,0.2)', borderRadius: '0 0 24px 24px',
            }} />
          </div>
        </div>
      </AnimatedSection>

      {/* ── FULL-SCREEN CINEMATIC REVEAL ── */}
      {phase === 'revealed' && (
        <div className="fixed inset-0 z-50 overflow-hidden" style={{ background: 'rgba(2,0,18,0.97)' }}>

          {/* Canvas confetti */}
          <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none" />

          {/* Concert light rays */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            {[
              { l:'8%',  c:'rgba(139,92,246,0.5)',  d:'3.2s', delay:'0s'    },
              { l:'20%', c:'rgba(255,215,0,0.35)',   d:'4.1s', delay:'0.4s'  },
              { l:'35%', c:'rgba(255,100,0,0.3)',    d:'3.7s', delay:'0.8s'  },
              { l:'50%', c:'rgba(168,85,247,0.45)',  d:'3.5s', delay:'0.2s'  },
              { l:'65%', c:'rgba(255,200,0,0.3)',    d:'4.3s', delay:'0.6s'  },
              { l:'80%', c:'rgba(139,92,246,0.4)',   d:'3.8s', delay:'1s'    },
              { l:'92%', c:'rgba(255,80,150,0.25)',  d:'4.0s', delay:'0.3s'  },
            ].map((ray, i) => (
              <div key={i} style={{
                position: 'absolute', top: '-5%', left: ray.l,
                width: 5, height: '75%',
                background: `linear-gradient(to bottom, ${ray.c} 0%, transparent 100%)`,
                filter: 'blur(8px)',
                transformOrigin: 'top center',
                animation: `sLightSweep ${ray.d} ease-in-out infinite alternate`,
                animationDelay: ray.delay,
              }} />
            ))}
          </div>

          {/* Crowd silhouette */}
          <div className="absolute bottom-0 left-0 right-0 pointer-events-none" style={{ height: 130 }}>
            <svg viewBox="0 0 1200 130" preserveAspectRatio="none" style={{ width: '100%', height: '100%' }}>
              {[60,120,180,240,300,360,420,480,540,600,660,720,780,840,900,960,1020,1080,1140].map((cx,i) => (
                <ellipse key={i} cx={cx} cy={130} rx={28+i%3*7} ry={55+i%5*14} fill={`rgba(${60+i%3*10},${35+i%4*5},${100+i%3*15},${0.6+i%3*0.05})`} />
              ))}
              {[60,180,300,420,540,660,780,900,1020,1140].map((x,i) => (
                <rect key={i} x={x-2} y={55+i%4*8} width={4} height={28} rx={2}
                  fill="rgba(140,80,200,0.7)"
                  transform={`rotate(${i%2===0?-25:22} ${x} ${55+i%4*8})`} />
              ))}
            </svg>
          </div>

          {/* Close */}
          <button onClick={close} className="absolute top-5 right-5 z-20 transition-all"
            style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.15)', borderRadius: 12, padding: '10px 14px', color: 'rgba(255,255,255,0.5)' }}
            onMouseEnter={e => e.currentTarget.style.color='white'}
            onMouseLeave={e => e.currentTarget.style.color='rgba(255,255,255,0.5)'}>
            <X size={20} />
          </button>

          {/* Center announcement */}
          <div className="absolute inset-0 flex items-center justify-center p-6" style={{ paddingBottom: 150 }}>
            <div style={{ animation: 'sRevealUp 0.8s cubic-bezier(0.22,1,0.36,1) forwards', textAlign: 'center' }}>

              {/* Parchment / Scroll card */}
              <div style={{
                position: 'relative',
                background: 'linear-gradient(160deg, #0f0520 0%, #1a0836 50%, #0a0218 100%)',
                border: '2px solid rgba(255,215,0,0.35)',
                borderRadius: 24,
                padding: '48px 64px 48px',
                boxShadow: '0 0 100px rgba(109,40,217,0.5), 0 0 60px rgba(255,215,0,0.08), inset 0 0 60px rgba(139,92,246,0.1)',
                animation: 'sScrollUnfurl 0.9s cubic-bezier(0.34,1.56,0.64,1) forwards',
                maxWidth: 640,
              }}>
                {/* Gold scroll rods */}
                <div style={{ position: 'absolute', top: -10, left: -20, right: -20, height: 20, background: 'linear-gradient(to bottom, #78350F, #FFD700, #D97706, #78350F)', borderRadius: 10, boxShadow: '0 0 24px rgba(255,215,0,0.7)' }} />
                <div style={{ position: 'absolute', bottom: -10, left: -20, right: -20, height: 20, background: 'linear-gradient(to bottom, #78350F, #FFD700, #D97706, #78350F)', borderRadius: 10, boxShadow: '0 0 24px rgba(255,215,0,0.7)' }} />

                {/* Fire emoji row */}
                <div style={{ fontSize: 52, marginBottom: 4, animation: 'bounce 1s ease-in-out infinite' }}>🔥</div>
                <div style={{ display: 'flex', justifyContent: 'center', gap: 12, marginBottom: 20 }}>
                  {['🎭','🎵','💃','🎮','🏆'].map((e,i) => (
                    <span key={i} style={{ fontSize: 24, animation: `pulse 1.2s ease-in-out ${i*0.15}s infinite` }}>{e}</span>
                  ))}
                </div>

                <p style={{ color: '#F59E0B', fontSize: 12, fontWeight: 700, letterSpacing: '0.45em', textTransform: 'uppercase', marginBottom: 14, animation: 'sFadeUp 0.5s ease 0.6s both', opacity: 0 }}>
                  ✦ The Most Awaited Fest Is Back ✦
                </p>

                {/* REVOTHSAVA */}
                <h1 style={{
                  fontFamily: "'Outfit', sans-serif", fontWeight: 900,
                  fontSize: 'clamp(3.2rem, 9vw, 6.5rem)', color: '#FFFFFF',
                  lineHeight: 1, marginBottom: 16, letterSpacing: '-0.02em',
                  textShadow: '0 0 40px rgba(139,92,246,0.9), 0 0 80px rgba(109,40,217,0.6), 0 0 160px rgba(255,215,0,0.15)',
                  animation: 'sRevothsavaGlow 2s ease-in-out infinite alternate',
                }}>
                  REVOTHSAVA
                </h1>

                {/* COMING SOON */}
                <div style={{
                  fontFamily: "'Outfit', sans-serif", fontWeight: 800,
                  fontSize: 'clamp(1.4rem, 3.5vw, 2.2rem)', letterSpacing: '0.12em',
                  background: 'linear-gradient(90deg, #FF3131, #FFD700, #FF6B00, #FFD700, #FF3131)',
                  WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
                  backgroundSize: '300% auto',
                  marginBottom: 24,
                  animation: 'sNeonSlide 2.5s linear infinite, sFadeUp 0.5s ease 1s both',
                  opacity: 0,
                }}>
                  COMING SOON 🚀
                </div>

                <p style={{ color: 'rgba(255,255,255,0.48)', fontSize: 15, maxWidth: 400, margin: '0 auto 28px', lineHeight: 1.7, animation: 'sFadeUp 0.5s ease 1.3s both', opacity: 0 }}>
                  Music · Dance · Drama · Competitions · Unforgettable Memories
                </p>

                <div style={{
                  display: 'inline-flex', alignItems: 'center', gap: 10,
                  background: 'rgba(139,92,246,0.15)', border: '1px solid rgba(139,92,246,0.45)',
                  borderRadius: 999, padding: '12px 28px',
                  animation: 'sFadeUp 0.5s ease 1.6s both', opacity: 0,
                }}>
                  <span style={{ width: 9, height: 9, background: '#8B5CF6', borderRadius: '50%', display: 'inline-block', animation: 'pulse 1s ease-in-out infinite' }} />
                  <span style={{ color: '#A78BFA', fontWeight: 700, fontSize: 12, letterSpacing: '0.35em', textTransform: 'uppercase' }}>Stay Tuned for Updates</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Keyframes */}
      <style>{`
        @keyframes sBoxShake {
          0%,100%{transform:translate(0)rotate(0)}
          10%{transform:translate(-10px,-4px)rotate(-6deg)}
          20%{transform:translate(10px,-2px)rotate(6deg)}
          30%{transform:translate(-8px,2px)rotate(-4deg)}
          40%{transform:translate(8px,0)rotate(4deg)}
          50%{transform:translate(-6px,-3px)rotate(-3deg)}
          60%{transform:translate(6px,1px)rotate(3deg)}
          80%{transform:translate(-3px,0)rotate(-1deg)}
        }
        @keyframes sBoxFloat {
          0%,100%{transform:translateY(0)}
          50%{transform:translateY(-12px)}
        }
        @keyframes sDot {
          0%{opacity:0.3;transform:scale(0.7)}
          100%{opacity:1;transform:scale(1.4)}
        }
        @keyframes sLightSweep {
          0%{transform:rotate(-22deg);opacity:0.4}
          100%{transform:rotate(22deg);opacity:1}
        }
        @keyframes sRevealUp {
          from{transform:translateY(50px)scale(0.88);opacity:0}
          to{transform:translateY(0)scale(1);opacity:1}
        }
        @keyframes sScrollUnfurl {
          from{transform:scaleY(0.2)scaleX(0.7);opacity:0}
          to{transform:scaleY(1)scaleX(1);opacity:1}
        }
        @keyframes sRevothsavaGlow {
          0%{text-shadow:0 0 40px rgba(139,92,246,0.9),0 0 80px rgba(109,40,217,0.6)}
          100%{text-shadow:0 0 60px rgba(168,85,247,1),0 0 120px rgba(139,92,246,0.8),0 0 200px rgba(255,215,0,0.25)}
        }
        @keyframes sNeonSlide {
          0%{background-position:0% center}
          100%{background-position:300% center}
        }
        @keyframes sFadeUp {
          from{opacity:0;transform:translateY(14px)}
          to{opacity:1;transform:translateY(0)}
        }
      `}</style>
    </section>
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function useInView(ref) {
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(([entry]) => { if (entry.isIntersecting) setInView(true); }, { threshold: 0.1 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [ref]);
  return inView;
}

function AnimatedSection({ children, className = '' }) {
  const ref = useRef(null);
  const inView = useInView(ref);
  return (
    <div ref={ref} className={`transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'} ${className}`}>
      {children}
    </div>
  );
}

const quickLinks = [
  { to: '/events',   icon: Calendar,      label: 'Events',          desc: 'Current, upcoming & past events',      color: 'from-red-600 to-rose-700',    glow: 'hover:shadow-red-500/25'    },
  { to: '/clubs',    icon: Star,          label: 'Clubs & Forums',  desc: 'Explore all campus clubs',             color: 'from-purple-600 to-violet-700', glow: 'hover:shadow-purple-500/25' },
  { to: '/members',  icon: Users,         label: 'Council Members', desc: 'Meet the team behind the council',     color: 'from-blue-600 to-indigo-700', glow: 'hover:shadow-blue-500/25'  },
  { to: '/gallery',  icon: Image,         label: 'Gallery',         desc: 'Memories and achievements',            color: 'from-teal-600 to-cyan-700',   glow: 'hover:shadow-teal-500/25'  },
  { to: '/complaint',icon: MessageSquare, label: 'Complaint Box',   desc: 'Submit concerns anonymously',          color: 'from-amber-600 to-yellow-700',glow: 'hover:shadow-amber-500/25' },
];

const stats = [
  { value: '5,000+', label: 'Students Served',  icon: Users    },
  { value: '50+',    label: 'Events per Year',   icon: Calendar },
  { value: '12+',    label: 'Active Clubs',       icon: Star     },
  { value: '38',     label: 'Council Members',    icon: Trophy   },
];

export default function Home() {
  const upcomingEvents = events.filter(e => e.category === 'upcoming').slice(0, 3);

  return (
    <div className="page-enter">
      {/* Hero */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden hero-gradient">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 -left-20 w-96 h-96 bg-reva-red/10 rounded-full blur-3xl animate-pulse-slow" />
          <div className="absolute bottom-1/4 -right-20 w-80 h-80 bg-reva-gold/5 rounded-full blur-3xl animate-pulse-slow" style={{ animationDelay: '1s' }} />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-reva-red/5 rounded-full blur-3xl" />
          <div className="absolute inset-0 opacity-5" style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,.1) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.1) 1px,transparent 1px)', backgroundSize: '50px 50px' }} />
        </div>

        <div className="relative max-w-5xl mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 bg-reva-red/15 border border-reva-red/30 rounded-full px-5 py-2 mb-8 animate-fade-in">
            <span className="w-2 h-2 bg-reva-red rounded-full animate-pulse" />
            <span className="text-reva-red text-sm font-semibold tracking-widest uppercase">REVA STUDENT COUNCIL</span>
          </div>
          <h1 className="font-outfit font-black text-5xl md:text-7xl lg:text-8xl text-white leading-none mb-6 animate-slide-up">
            Your Voice.<br />
            <span className="gradient-text">Your Future.</span>
          </h1>
          <p className="text-white/60 text-lg md:text-xl max-w-2xl mx-auto mb-10 animate-fade-in leading-relaxed">
            {councilInfo.description}
          </p>
          <div className="flex flex-wrap justify-center gap-4 animate-fade-in">
            <Link to="/events" className="btn-primary inline-flex items-center gap-2 text-base">Explore Events <ArrowRight size={18} /></Link>
            <Link to="/clubs"  className="btn-outline inline-flex items-center gap-2 text-base">Join a Club <ChevronRight size={18} /></Link>
          </div>
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
            <div className="w-6 h-10 rounded-full border-2 border-white/20 flex items-start justify-center pt-2">
              <div className="w-1.5 h-3 bg-white/40 rounded-full" />
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-reva-navylight border-y border-white/10 py-8">
        <div className="max-w-5xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, i) => (
              <div key={i} className="text-center">
                <div className="font-outfit font-black text-3xl md:text-4xl text-reva-red mb-1">{stat.value}</div>
                <div className="text-white/50 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Links */}
      <section className="section-padding max-w-7xl mx-auto">
        <AnimatedSection>
          <div className="text-center mb-12">
            <h2 className="section-title">Explore the Council</h2>
            <p className="section-subtitle">Everything you need, right at your fingertips</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {quickLinks.map((link, i) => {
              const Icon = link.icon;
              return (
                <Link key={link.to} to={link.to}
                  className={`glass-card p-6 card-hover group cursor-pointer hover:shadow-xl ${link.glow} transition-all duration-300`}
                  style={{ animationDelay: `${i * 100}ms` }}>
                  <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${link.color} flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                    <Icon size={26} className="text-white" />
                  </div>
                  <h3 className="font-outfit font-bold text-xl text-white mb-2 group-hover:text-reva-gold transition-colors">{link.label}</h3>
                  <p className="text-white/50 text-sm mb-4">{link.desc}</p>
                  <div className="flex items-center gap-1 text-reva-red text-sm font-semibold group-hover:gap-2 transition-all duration-200">
                    Explore <ArrowRight size={14} />
                  </div>
                </Link>
              );
            })}
          </div>
        </AnimatedSection>
      </section>

      <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-16 xl:px-24"><div className="divider" /></div>

      {/* Upcoming Events */}
      <section className="section-padding max-w-7xl mx-auto">
        <AnimatedSection>
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="section-title">Upcoming Events</h2>
              <p className="text-white/50 text-base">Don't miss what's coming up next</p>
            </div>
            <Link to="/events" className="btn-outline text-sm py-2 px-4 hidden sm:inline-flex items-center gap-2">View All <ArrowRight size={14} /></Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {upcomingEvents.map((event, i) => (
              <div key={event.id} className="glass-card p-6 card-hover group" style={{ animationDelay: `${i * 120}ms` }}>
                <div className="flex items-center gap-2 mb-4"><span className="badge-gold">{event.tags[0]}</span></div>
                <h3 className="font-outfit font-bold text-lg text-white mb-2 group-hover:text-reva-gold transition-colors">{event.title}</h3>
                <p className="text-white/50 text-sm mb-4 line-clamp-2">{event.description}</p>
                <div className="space-y-1.5 text-xs text-white/40">
                  <div className="flex items-center gap-2"><Calendar size={12} className="text-reva-red" />{event.date}</div>
                  <div className="flex items-center gap-2"><Zap size={12} className="text-reva-gold" />{event.venue}</div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 text-center sm:hidden">
            <Link to="/events" className="btn-outline text-sm inline-flex items-center gap-2">View All Events <ArrowRight size={14} /></Link>
          </div>
        </AnimatedSection>
      </section>

      <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-16 xl:px-24"><div className="divider" /></div>

      {/* About */}
      <section className="section-padding max-w-7xl mx-auto">
        <AnimatedSection>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-reva-gold/10 border border-reva-gold/20 rounded-full px-4 py-1.5 mb-6">
                <BookOpen size={14} className="text-reva-gold" />
                <span className="text-reva-gold text-xs font-semibold">About the Council</span>
              </div>
              <h2 className="section-title mb-4">Who We Are</h2>
              <p className="text-white/60 leading-relaxed mb-6">
                The REVA Student Council was established in 2024 as the official student governing body of REVA University.
                We are a team of passionate students committed to making campus life better for every student.
              </p>
              <p className="text-white/60 leading-relaxed mb-8">
                From organizing mega-events to resolving student concerns, from managing clubs to advocating for student rights —
                we are here to be <span className="text-white font-semibold">your voice</span> on campus.
              </p>
              <div className="grid grid-cols-2 gap-4">
                {[['Student Welfare','🤝'],['Campus Events','🎉'],['Student Rights','⚖️'],['Club Management','🌟']].map(([item,emoji]) => (
                  <div key={item} className="flex items-center gap-3 glass-card px-4 py-3">
                    <span className="text-lg">{emoji}</span>
                    <span className="text-white/70 text-sm font-medium">{item}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="glass-card p-8 relative z-10">
                <div className="font-outfit text-6xl font-black text-reva-red/20 leading-none mb-4">"</div>
                <p className="text-white/80 italic text-lg leading-relaxed mb-6">
                  We believe every student deserves a platform to be heard, an opportunity to lead, and a community to belong to.
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-reva-red to-reva-darkred rounded-full flex items-center justify-center font-outfit font-black text-white text-sm">S</div>
                  <div>
                    <div className="font-semibold text-white text-sm">Sharan M</div>
                    <div className="text-white/40 text-xs">President, REVA Student Council</div>
                  </div>
                </div>
              </div>
              <div className="absolute inset-0 bg-reva-red/10 rounded-2xl blur-xl translate-x-4 translate-y-4" />
            </div>
          </div>
        </AnimatedSection>
      </section>

      <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-16 xl:px-24"><div className="divider" /></div>

      {/* 🎁 REVOTHSAVA SURPRISE BOX */}
      <SurpriseBox />

      <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-16 xl:px-24"><div className="divider" /></div>

      {/* Instagram */}
      <section className="section-padding max-w-7xl mx-auto">
        <AnimatedSection>
          <div className="relative overflow-hidden rounded-3xl" style={{ background: 'linear-gradient(135deg,#833AB4 0%,#FD1D1D 50%,#FCB045 100%)' }}>
            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
            <div className="relative p-10 md:p-16 text-center">
              <div className="text-5xl mb-4">📸</div>
              <h2 className="font-outfit font-black text-3xl md:text-4xl text-white mb-4">Stay Connected</h2>
              <p className="text-white/80 text-lg mb-8 max-w-xl mx-auto">
                Follow <span className="font-bold text-white">@reva_student_affairs</span> on Instagram for real-time updates,
                event highlights, announcements, and behind-the-scenes moments.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="https://www.instagram.com/reva_student_affairs/" target="_blank" rel="noreferrer"
                  className="inline-flex items-center justify-center gap-2 bg-white text-gray-900 font-bold px-8 py-3.5 rounded-xl hover:scale-105 transition-transform duration-200">
                  <Instagram size={20} /> Follow on Instagram
                </a>
              </div>
              <p className="text-white/50 text-sm mt-6">🔔 Turn on notifications so you never miss an update!</p>
            </div>
          </div>
        </AnimatedSection>
      </section>
    </div>
  );
}
